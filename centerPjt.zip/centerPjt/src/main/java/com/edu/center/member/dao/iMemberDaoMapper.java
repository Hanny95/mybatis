package com.edu.center.member.dao;

import java.util.List;

import com.edu.center.member.vo.MemberVo;

// 구현부가 없음 선언부만 존재 (Dao에서 COPY 함)
public interface iMemberDaoMapper {
	
	public void memberJoinConfirm(MemberVo memberVo);
	public int memberLoginConfirm(MemberVo memberVo);
	public List<MemberVo> memberModify(MemberVo memberVo);
	public void memberModifyConfirm(MemberVo memberVo);
	public void memberDeleteConfirm(MemberVo memberVo);
	public List<MemberVo> memberList();
	
	
}
