package com.edu.center.member.vo;

public class MemberVo {
	
	private int m_no;
	private String m_id;
	private String m_pw;
	private String m_name;
	private String m_gender;
	private int m_age;
	private int m_grade;
	private String m_major;
	private String m_reg_date;
	private String m_mod_date;
	
	
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public String getM_pw() {
		return m_pw;
	}
	public void setM_pw(String m_pw) {
		this.m_pw = m_pw;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getM_gender() {
		return m_gender;
	}
	public void setM_gender(String m_gender) {
		this.m_gender = m_gender;
	}
	public int getM_age() {
		return m_age;
	}
	public void setM_age(int m_age) {
		this.m_age = m_age;
	}
	public int getM_grade() {
		return m_grade;
	}
	public void setM_grade(int m_grade) {
		this.m_grade = m_grade;
	}
	public String getM_major() {
		return m_major;
	}
	public void setM_major(String m_major) {
		this.m_major = m_major;
	}
	public String getM_reg_date() {
		return m_reg_date;
	}
	public void setM_reg_date(String m_reg_date) {
		this.m_reg_date = m_reg_date;
	}
	public String getM_mod_date() {
		return m_mod_date;
	}
	public void setM_mod_date(String m_mod_date) {
		this.m_mod_date = m_mod_date;
	}
	
	
	

	
	
}
